package com.cg.optfs.exception;

public class TutorNotFoundException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public TutorNotFoundException(String message) {
		super(message);
		
	}

}
