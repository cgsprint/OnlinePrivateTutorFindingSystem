package com.cg.optfs.exception;

public class ParentNotFoundException extends Exception {

	public ParentNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

}
