package com.cg.optfs.exception;

public class TutorException {

}
