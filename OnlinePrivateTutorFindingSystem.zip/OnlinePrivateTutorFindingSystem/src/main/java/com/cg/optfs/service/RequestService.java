package com.cg.optfs.service;

import java.util.List;

import com.cg.optfs.entity.Request;

public interface RequestService {
/**
 * @return request
 * @author CHANCHAL
 */
public List<Request> viewRequest();
}
