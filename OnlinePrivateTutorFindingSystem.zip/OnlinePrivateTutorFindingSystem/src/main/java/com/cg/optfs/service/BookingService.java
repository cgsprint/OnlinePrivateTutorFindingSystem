package com.cg.optfs.service;

import java.util.List;

import com.cg.optfs.entity.Booking;

public interface BookingService {

	public List<Booking> viewBooking();
}
