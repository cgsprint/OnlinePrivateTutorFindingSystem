package com.cg.optfs.service;

import java.util.List;

import com.cg.optfs.entity.BookedTutor;

public interface BookedTutorService {
	/**
	 * @return Booked Tutor
	 * @author CHANCHAL
	 */
	public List<BookedTutor> viewBookedTutor();
}
