package com.cg.optfs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinePrivateTutorFindingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinePrivateTutorFindingSystemApplication.class, args);
	}

}
